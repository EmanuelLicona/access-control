@extends('layouts.app')

@include('layouts._partials.header_single_page')

@section('title', 'Access Control')

@section('content')

    <div class="container text-center">
        <h1>Pagina de bienvenida</h1>
    </div>
@endsection
