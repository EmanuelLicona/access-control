<div class="table-responsive">
    <table class="table">
       
        <caption>Lista de registros de acceso</caption>

        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Primer Nombre</th>
                <th scope="col">Primer Apellido</th>
                <th scope="col">Codigo</th>
                <th scope="col">Fecha</th>
            </tr>
        </thead>
        <tbody>


            <?php $__empty_1 = true; $__currentLoopData = $access; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->user->first_name); ?></td>
                    <td><?php echo e($item->user->last_name); ?></td>
                    <td><?php echo e($item->user->code); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No hay registros</td>
                </tr>
            <?php endif; ?>
          
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\alico\OneDrive\Escritorio\access-control\resources\views/access/_partials/table.blade.php ENDPATH**/ ?>