

<?php echo $__env->make('layouts._partials.header_single_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-md-6 mx-auto p-5 border rounded">
            <h1 class="text-center">Inicio de sesión</h1>
            
            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('auth.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="inputEmail" class="form-label">Correo</label>
                    <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp"
                        value="admin@example.com" name="email">
                </div>
                <div class="mb-3">
                    <label for="inputPassword" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" id="inputPassword" value="password" name="password">
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="inputRemember" name="remember">
                    <label class="form-check-label" for="inputRemember">Recuerdame</label>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\access-control\resources\views/auth/login.blade.php ENDPATH**/ ?>