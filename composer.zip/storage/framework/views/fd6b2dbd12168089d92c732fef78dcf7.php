<div class="table-responsive">
    <table class="table">
       
        <caption>List of users</caption>
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Primer Nombre</th>
                <th scope="col">Primer Apellido</th>
                <th scope="col">Correo Electronico</th>
                <th scope="col">Codigo</th>
            </tr>
        </thead>
        <tbody>


            
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($user->first_name); ?></td>
                    <td><?php echo e($user->last_name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->code); ?></td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No hay registros</td>
                </tr>
            <?php endif; ?>
          
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\alico\OneDrive\Escritorio\access-control\resources\views/users/_partials/table.blade.php ENDPATH**/ ?>