<?php echo $__env->make('layouts._partials.header_single_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Access Control'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container text-center">
        <h1>Pagina de bienvenida</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\access-control\resources\views/welcome.blade.php ENDPATH**/ ?>