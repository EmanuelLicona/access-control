<header>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Icono</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('users.index')); ?>">Usuarios</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('access.index')); ?>">Registros de accesos</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="<?php echo e(route('auth.destroy')); ?>">Cerrar sesion</a>
                    </li>

                    
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\Users\alico\OneDrive\Escritorio\access-control\resources\views/layouts/_partials/header_admin.blade.php ENDPATH**/ ?>