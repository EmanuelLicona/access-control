

<?php echo $__env->make('layouts._partials.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>
            
            Hola Nombre del usuario
        </h1>
    </div>

    <div class="container">
        <div class="d-flex justify-content-between">
            <h3>Lista de usuarios</h3>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Crear usuario</a>
        </div>

        <?php echo $__env->make('users._partials.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alico\OneDrive\Escritorio\access-control\resources\views/users/index.blade.php ENDPATH**/ ?>