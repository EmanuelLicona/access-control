

<?php $__env->startSection('title', 'Access Control'); ?>

<?php echo $__env->make('layouts._partials.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between">
            <h3>Lista de accesos registrados</h3>
        </div>

        <?php echo $__env->make('access._partials.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alico\OneDrive\Escritorio\access-control\resources\views/access/index.blade.php ENDPATH**/ ?>