<?php echo $__env->make('layouts._partials.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Access Control'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container text-center">
        <h1>Home</h1>
        <p>Hola <?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alico\OneDrive\Escritorio\access-control\resources\views/home.blade.php ENDPATH**/ ?>